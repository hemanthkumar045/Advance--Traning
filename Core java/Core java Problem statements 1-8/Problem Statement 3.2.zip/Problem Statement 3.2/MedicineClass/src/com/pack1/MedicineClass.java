package com.pack1;


public class MedicineClass
{
	public void displayLabel()
	{
		System.out.println("Company :Agro Pharma ");
		System.out.println("Address : Delhi");
		}
	}
class Tablet extends MedicineClass{
	 
public void displayLabel()
{
	System.out.println("store in a cool dry place");
	}
}
class Syrup extends MedicineClass
{public void displayLabel()
{
	System.out.println("Consumption as directed by thephysician");
	}
}
class Ointment extends MedicineClass
{
	public void displayLabel()
	{
		System.out.println("for external use only");
		}
	}